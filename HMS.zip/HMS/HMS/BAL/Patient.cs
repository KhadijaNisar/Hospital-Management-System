﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HMS.BAL
{
    public class Patient : People
    {
        private string patientId;
        private string gender;
        private int age;
        //private Login patientLogin;
        public string PatientId
        {
            get
            {
                return patientId;
            }
        }
        public string Gender
        {
            get
            {
                return gender;
            }
        }
        public int Age
        {
            get
            {
                return age;
            }
        }
        public Patient(string cnic,string name,string phoneNo,string address,string gender,int age):base(cnic,name,phoneNo,address)
        {
            //this.patientId = patientId;
            this.gender = gender;
            this.age = age;
        }

       /* public  void PatientLogin(Login patientLogin)
        {
            this.patientLogin = patientLogin;
        }*/
       /* public Appointment Appointment
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }*/
    }
}
