﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using HMS.BAL;
using HMS.DAL;
namespace HMS.PAL
{
    public partial class UpdatePatient : Form
    {
        public UpdatePatient()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string Update_CNIC = txtCNIC.Text;
            string Update_Name = txtName.Text;
            string Update_Address = txtAddress.Text;
            int Update_Age = int.Parse(txtAge.Text);
            string Update_Phone = txtCell.Text;
            string Update_Gender=txtGender.Text;
            Patient p = new Patient(Update_CNIC, Update_Name,Update_Phone, Update_Address, Update_Gender, Update_Age);
            DAL.DAL.UpdatePatient(p);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            View v = new View();
            v.Show();
            this.Hide();
        }
    }
}
