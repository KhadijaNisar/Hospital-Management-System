﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HMS.BAL;
using HMS.DAL;
using System.Data.SqlClient;
namespace HMS.PAL
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           // string userName = txtUserName.Text;
            //string password = txtPassword.Text;
            SqlConnection connection = DAL.DAL.GetConnection();
            string query="SELECT * FROM LOGIN WHERE Username='"+txtUserName.Text+"'AND Pasword='"+txtPassword.Text+"'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read() ==true)
            {
                MessageBox.Show("Wrong Username or Password !!!");
                Portal p = new Portal();
                p.Show();
                this.Hide();
            }
            else
            {
                
                MessageBox.Show("Login was Successfull !!!");
                View v1 = new View();
                v1.Show();
                this.Hide();
            }
           /* BAL.Login log1 = new BAL.Login(userName, password);
            if(HMS.DAL.DAL.Admin_Login(log1))
            {
                View v1 = new View();
                v1.Show();
                this.Hide();
            }
            else
            {
                Portal p = new Portal();
                p.Show();
                this.Hide();
            }*/
        }
    }
}
