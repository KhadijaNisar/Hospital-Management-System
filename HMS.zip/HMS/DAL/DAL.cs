﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using HMS.BAL;
namespace HMS.DAL
{
    class DAL
    {
        //T o get Connection from the database
        public static SqlConnection GetConnection()
        {
            string strconnection = "Data Source=MANI\\SQLEXPRESS;Initial Catalog=Project_KIA;Integrated Security=True";
            SqlConnection connection = new SqlConnection(strconnection);
            try
            {
                connection.Open();
                MessageBox.Show("Connection was Successfull !!!");
            }
            catch(SqlException)
            {
                MessageBox.Show("Connection was Unsuccessfull !!");
                connection.Close();
            }
            return connection;
        }
        // To get Data from the Patient Table
        public static SqlDataReader GetPatientData()
        {
            SqlConnection connection = DAL.GetConnection();
            string query = "SELECT * FROM PATIENT";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            return reader;
        }
        // To get Data from the Doctor Table
        public static SqlDataReader GetDoctorData()
        {
            SqlConnection connection = DAL.GetConnection();
            string query = "SELECT * FROM DOCTOR";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            return reader;
        }
        //To get Data from the PrescriptionTable
        public static SqlDataReader GetPrescriptionFormCNIC(string CNIC)
        {
            SqlConnection connection = DAL.GetConnection();
            string query = "SELECT * FROM PRESCRIPTION WHERE Patient_CNIC=@CNIC;";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@CNIC", CNIC);
            SqlDataReader reader = command.ExecuteReader();
            return reader;
        }
        //Login verification
        public static bool Admin_Login(BAL.Login login)
        {
            SqlConnection connection = DAL.GetConnection();
            string query = "SELECT COUNT(*) FROM LOGIN WHERE Username=@userName AND Pasword=@password;";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@userName", login.UserName);
            command.Parameters.AddWithValue("@password", login.Password);
            int result = (int)command.ExecuteScalar();
            if (result == 1)
            {
                MessageBox.Show("Login was Successfull !!!");
                return true;
            }
            else
            {
                MessageBox.Show("Wrong Username or Password !!!");
                return false;
            }
        }
    }
}
