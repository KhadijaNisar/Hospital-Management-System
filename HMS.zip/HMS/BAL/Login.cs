﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HMS.BAL
{
    public class Login
    {
        private string userName;
        private string password;

        public string UserName
        {
            get
            {
                return userName;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
        }
        public Login(string userName,string password)
        {
            this.userName = userName;
            this.password = password;
        }
    }
}
