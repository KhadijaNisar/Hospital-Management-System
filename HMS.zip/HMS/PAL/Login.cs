﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HMS.BAL;
using HMS.DAL;
namespace HMS.PAL
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string userName = txtUserName.Text.ToString();
            string password = txtPassword.Text.ToString();
            BAL.Login log1 = new BAL.Login(userName, password);
            bool test = HMS.DAL.DAL.Admin_Login(log1);
            if(test)
            {
                View v1 = new View();
                v1.Show();
                this.Hide();
            }
            else
            {
                Portal p = new Portal();
                p.Show();
                this.Hide();
            }
        }
    }
}
